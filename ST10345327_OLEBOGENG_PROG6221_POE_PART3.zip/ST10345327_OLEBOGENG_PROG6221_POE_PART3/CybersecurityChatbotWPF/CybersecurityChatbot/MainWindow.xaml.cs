﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CybersecurityChatbot
{
    public partial class MainWindow : Window
    {
        private ChatbotLogic chatbot = new ChatbotLogic(); // Instance for chatbot logic
        private List<(string Title, string Description, DateTime? Reminder, bool Completed)> tasks = new(); // List to store tasks
        private List<(string Question, List<string> Options, int CorrectAnswer, string Feedback)> quizQuestions = new()
        {
            ("What is phishing?", new List<string> { "A virus", "A scam email", "A security tool" }, 1, "Phishing tricks you into sharing info."),
            ("Best Wi-Fi security?", new List<string> { "No password", "Strong password + VPN", "Public network" }, 1, "Use a VPN for safety.")
        };
        private int currentQuestionIndex = 0; // Tracks current quiz question
        private int score = 0; // Tracks quiz score
        private int? selectedAnswer = null; // Stores selected answer index

        public MainWindow()
        {
            InitializeComponent(); // Initializes the XAML-defined UI
            DisplayAsciiArt(); // Displays the ASCII art on startup
            PlayWelcomeSound(); // Attempts to play the welcome sound
            LoadTasks(); // Loads existing tasks into the UI
            StartGame(); // Initializes the mini-game
            UpdateActivityLog(); // Updates the activity log
            RenderScoreGraph(); // Renders the initial score graph
            SetInitialVisibility(); // Sets initial visibility of sections
        }

        // Displays the ASCII art in the chat area
        private void DisplayAsciiArt()
        {
            if (AsciiArt != null)
            {
                AsciiArt.Text = "**** CYBERSECURE CHATBOT ****\n" +
                               "*                          *\n" +
                               "*  PROTECTING YOUR DATA    *\n" +
                               "*                          *\n" +
                               "****************************";
                chatbot.AddToActivityLog("Displayed welcome ASCII art");
            }
        }

        // Attempts to play the welcome sound with error handling
        private void PlayWelcomeSound()
        {
            if (WelcomeAudio != null)
            {
                try
                {
                    // Sets the source to a relative URI; ensure welcome.wav is in the Audio folder
                    WelcomeAudio.Source = new Uri("Audio/welcome.wav", UriKind.Relative);
                    WelcomeAudio.LoadedBehavior = MediaState.Manual; // Manual control of playback
                    WelcomeAudio.MediaOpened += (s, e) =>
                    {
                        WelcomeAudio.Play(); // Plays the sound when ready
                        chatbot.AddToActivityLog("Welcome sound played successfully");
                    };
                    WelcomeAudio.MediaEnded += (s, e) => WelcomeAudio.Stop(); // Stops after playback
                    WelcomeAudio.MediaFailed += (s, e) =>
                    {
                        chatbot.AddToActivityLog($"Sound failed: {e.ErrorException.Message}");
                    };
                }
                catch (Exception ex)
                {
                    chatbot.AddToActivityLog($"Audio initialization error: {ex.Message}");
                }
            }
        }

        // Renders a bar graph of quiz scores on the Canvas
        private void RenderScoreGraph()
        {
            if (ScoreGraph != null)
            {
                ScoreGraph.Children.Clear();
                double maxScore = quizQuestions.Count;
                double barWidth = 50;
                double barSpacing = 10;
                double canvasHeight = ScoreGraph.Height - 20; // Reserve space for labels

                for (int i = 0; i < quizQuestions.Count; i++)
                {
                    double barHeight = (score >= i + 1 ? 1 : 0) * (canvasHeight * (1.0 / maxScore));
                    Rectangle bar = new Rectangle
                    {
                        Width = barWidth,
                        Height = barHeight,
                        Fill = score >= i + 1 ? Brushes.Green : Brushes.Gray,
                        Margin = new Thickness(i * (barWidth + barSpacing), canvasHeight - barHeight, 0, 0)
                    };
                    ScoreGraph.Children.Add(bar);
                }

                TextBlock label = new TextBlock
                {
                    Text = $"Score: {score}/{quizQuestions.Count}",
                    FontSize = 12,
                    Margin = new Thickness(0, canvasHeight + 5, 0, 0)
                };
                ScoreGraph.Children.Add(label);
            }
        }

        // Loads tasks into the TaskList control
        private void LoadTasks()
        {
            if (TaskList != null)
            {
                TaskList.Items.Clear();
                foreach (var task in tasks)
                {
                    TaskList.Items.Add($"{task.Title} - {task.Description} {(task.Completed ? "[Completed]" : "")}");
                }
            }
        }

        // Handles adding a new task
        private void AddTaskButton_Click(object sender, RoutedEventArgs e)
        {
            if (TaskTitle != null && TaskDescription != null &&
                !string.IsNullOrWhiteSpace(TaskTitle.Text) && !string.IsNullOrWhiteSpace(TaskDescription.Text))
            {
                DateTime? reminder = null;
                if (TaskReminder != null && int.TryParse(TaskReminder.Text, out int days))
                    reminder = DateTime.Now.AddDays(days);

                tasks.Add((TaskTitle.Text, TaskDescription.Text, reminder, false));
                chatbot.AddToActivityLog($"Added task: {TaskTitle.Text}");
                LoadTasks();
                TaskTitle.Text = ""; TaskDescription.Text = ""; TaskReminder.Text = "";
                UpdateActivityLog();
            }
        }

        // Handles deleting the selected task
        private void DeleteTaskButton_Click(object sender, RoutedEventArgs e)
        {
            if (TaskList != null && TaskList.SelectedIndex >= 0)
            {
                tasks.RemoveAt(TaskList.SelectedIndex);
                chatbot.AddToActivityLog("Deleted a task");
                LoadTasks();
                UpdateActivityLog();
            }
        }

        // Marks the selected task as completed
        private void CompleteTaskButton_Click(object sender, RoutedEventArgs e)
        {
            if (TaskList != null && TaskList.SelectedIndex >= 0)
            {
                var task = tasks[TaskList.SelectedIndex];
                tasks[TaskList.SelectedIndex] = (task.Title, task.Description, task.Reminder, true);
                chatbot.AddToActivityLog($"Completed: {task.Title}");
                LoadTasks();
                UpdateActivityLog();
            }
        }

        // Handles Enter key press for sending messages
        private void UserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) SendButton_Click(sender, e);
        }

        // Processes user chat input
        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            if (UserInput != null && ChatOutput != null && !string.IsNullOrWhiteSpace(UserInput.Text))
            {
                string response = chatbot.ProcessInput(UserInput.Text);
                ChatOutput.Text = response;
                chatbot.StoreUserMemory(UserInput.Text);
                UserInput.Text = "";
                UpdateActivityLog();
            }
        }

        // Initializes the mini-game
        private void StartGame()
        {
            if (quizQuestions.Count > 0)
            {
                currentQuestionIndex = 0;
                score = 0;
                ShowQuestion();
            }
        }

        // Displays the current quiz question and options
        private void ShowQuestion()
        {
            if (GameQuestion != null && GameOptions != null && currentQuestionIndex < quizQuestions.Count)
            {
                GameQuestion.Text = quizQuestions[currentQuestionIndex].Question;
                GameOptions.Children.Clear();
                for (int i = 0; i < quizQuestions[currentQuestionIndex].Options.Count; i++)
                {
                    var button = new RadioButton
                    {
                        Content = quizQuestions[currentQuestionIndex].Options[i],
                        GroupName = "Quiz",
                        Margin = new Thickness(0, 5, 0, 0),
                        IsChecked = false // Ensure only one can be selected
                    };
                    int index = i;
                    button.Click += (s, e) => selectedAnswer = index;
                    GameOptions.Children.Add(button);
                }
                GameResult.Text = "";
                RenderScoreGraph();
            }
        }

        // Submits the quiz answer and updates the game state
        private void SubmitAnswerButton_Click(object sender, RoutedEventArgs e)
        {
            if (GameResult != null && selectedAnswer.HasValue)
            {
                bool isCorrect = selectedAnswer.Value == quizQuestions[currentQuestionIndex].CorrectAnswer;
                if (isCorrect) score++;
                GameResult.Text = isCorrect ? "Correct!" : "Wrong!";
                GameResult.Text += $" {quizQuestions[currentQuestionIndex].Feedback}";
                GameResult.Foreground = isCorrect ? Brushes.Green : Brushes.Red;
                chatbot.AddToActivityLog($"Quiz: {GameQuestion.Text} - {GameResult.Text}");

                if (isCorrect && currentQuestionIndex < quizQuestions.Count - 1)
                {
                    currentQuestionIndex++;
                    ShowQuestion();
                }
                else
                {
                    GameResult.Text += $"\nFinal Score: {score}/{quizQuestions.Count}";
                    chatbot.AddToActivityLog($"Quiz ended. Score: {score}/{quizQuestions.Count}");
                }
                selectedAnswer = null;
                RenderScoreGraph();
            }
        }

        // Updates the activity log display
        private void UpdateActivityLog()
        {
            if (ActivityLogList != null)
            {
                ActivityLogList.Items.Clear();
                foreach (string log in chatbot.GetActivityLog())
                {
                    ActivityLogList.Items.Add(log);
                }
            }
        }

        // Sets initial visibility of sections, showing only Chat by default
        private void SetInitialVisibility()
        {
            ChatBorder.Visibility = Visibility.Visible;
            TaskBorder.Visibility = Visibility.Collapsed;
            QuizBorder.Visibility = Visibility.Collapsed;
            LogBorder.Visibility = Visibility.Collapsed;
        }

        // Menu click handlers to toggle section visibility
        private void ShowChat_Click(object sender, RoutedEventArgs e)
        {
            ChatBorder.Visibility = Visibility.Visible;
            TaskBorder.Visibility = Visibility.Collapsed;
            QuizBorder.Visibility = Visibility.Collapsed;
            LogBorder.Visibility = Visibility.Collapsed;
        }

        private void ShowTasks_Click(object sender, RoutedEventArgs e)
        {
            ChatBorder.Visibility = Visibility.Collapsed;
            TaskBorder.Visibility = Visibility.Visible;
            QuizBorder.Visibility = Visibility.Collapsed;
            LogBorder.Visibility = Visibility.Collapsed;
        }

        private void ShowQuiz_Click(object sender, RoutedEventArgs e)
        {
            ChatBorder.Visibility = Visibility.Collapsed;
            TaskBorder.Visibility = Visibility.Collapsed;
            QuizBorder.Visibility = Visibility.Visible;
            LogBorder.Visibility = Visibility.Collapsed;
            StartGame(); // Restart quiz when shown
        }

        private void ShowLog_Click(object sender, RoutedEventArgs e)
        {
            ChatBorder.Visibility = Visibility.Collapsed;
            TaskBorder.Visibility = Visibility.Collapsed;
            QuizBorder.Visibility = Visibility.Collapsed;
            LogBorder.Visibility = Visibility.Visible;
        }
    }
}