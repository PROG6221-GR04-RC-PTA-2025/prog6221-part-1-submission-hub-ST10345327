using System;
using System.Collections.Generic;
using System.Linq;

namespace CybersecurityChatbot
{
    public class ChatbotLogic
    {
        private List<string> activityLog = new List<string>(); // Stores all activity log entries

        // Dictionary mapping cybersecurity topics to responses
        private Dictionary<string, string> topicResponses = new Dictionary<string, string>
        {
            {"phishing", "Phishing is a scam to steal your info. Don’t click unknown links!"},
            {"wifi security", "Use a strong password and VPN for Wi-Fi security."},
            {"passwords", "Create unique passwords with letters, numbers, and symbols."},
            {"malware", "Install antivirus to protect against malware."},
            {"social engineering", "Be cautious of tricks asking for personal info."}
        };

        // Lists for sentiment analysis
        private List<string> positiveWords = new List<string> { "good", "great", "safe", "happy" };
        private List<string> negativeWords = new List<string> { "bad", "unsafe", "risky", "sad" };

        // Adds an entry to the activity log with a timestamp
        public void AddToActivityLog(string entry)
        {
            activityLog.Add($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {entry}");
            if (activityLog.Count > 10) activityLog.RemoveAt(0); // Limits log to 10 entries
        }

        // Returns a copy of the activity log
        public List<string> GetActivityLog() => new List<string>(activityLog);

        // Stores user input in memory for tracking
        public void StoreUserMemory(string input) => AddToActivityLog($"User said: {input}");

        // Processes user input and returns an appropriate response
        public string ProcessInput(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return "Please type a message!";

            input = input.ToLower().Trim();
            AddToActivityLog($"Processing: {input}");

            // Handle task addition command
            if (input.StartsWith("add task"))
            {
                var parts = input.Split(new[] { "add task - " }, StringSplitOptions.None);
                if (parts.Length > 1)
                {
                    string task = parts[1].Trim();
                    AddToActivityLog($"Task added: {task}");
                    return $"Task added: {task}";
                }
                return "Format: add task - [task name]";
            }

            // Display activity log on command
            if (input == "show activity log")
            {
                return activityLog.Count > 0 ? string.Join("\n", activityLog) : "No activity logged yet.";
            }

            // Match input to a cybersecurity topic
            var topic = topicResponses.Keys.FirstOrDefault(key => input.Contains(key));
            if (topic != null) return topicResponses[topic];

            // Perform sentiment analysis
            int positiveScore = input.Split().Count(w => positiveWords.Contains(w));
            int negativeScore = input.Split().Count(w => negativeWords.Contains(w));
            string sentiment = positiveScore > negativeScore ? "positive" : negativeScore > positiveScore ? "negative" : "neutral";

            return sentiment switch
            {
                "positive" => "Great to hear! What cybersecurity topic interests you?",
                "negative" => "Sorry about that! Let’s learn about security.",
                _ => "Not sure? Try 'phishing' or 'passwords'!"
            };
        }
    }
}